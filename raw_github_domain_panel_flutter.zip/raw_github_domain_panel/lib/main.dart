import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Ganti URL ini jika username/repository/branch/file kamu berbeda.
const rawJsonUrl = 'https://raw.githubusercontent.com/loljirlah-hub/contoh/main/domain-panel.json';

void main() => runApp(const DomainApp());

class DomainApp extends StatelessWidget {
  const DomainApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Domain Panel',
    theme: ThemeData(colorSchemeSeed: Colors.blue, useMaterial3: true),
    home: const DomainPage(),
  );
}

class DomainPage extends StatefulWidget {
  const DomainPage({super.key});
  @override
  State<DomainPage> createState() => _DomainPageState();
}

class _DomainPageState extends State<DomainPage> {
  bool loading = true;
  String? error;
  Map<String, dynamic> data = {};

  Future<void> loadData() async {
    setState(() { loading = true; error = null; });
    try {
      final uri = Uri.parse(rawJsonUrl).replace(queryParameters: {
        't': DateTime.now().millisecondsSinceEpoch.toString(),
      });
      final response = await http.get(uri).timeout(const Duration(seconds: 20));
      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode}. Periksa URL Raw GitHub.');
      }
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('Format JSON harus berupa object.');
      }
      if (!mounted) return;
      setState(() { data = decoded; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  void initState() { super.initState(); loadData(); }

  @override
  Widget build(BuildContext context) {
    final app = data['app'] is Map
        ? Map<String, dynamic>.from(data['app']) : <String, dynamic>{};
    final domains = data['domains'] is List ? data['domains'] as List : [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Domain Panel'),
        actions: [
          IconButton(onPressed: loading ? null : loadData,
            icon: const Icon(Icons.refresh), tooltip: 'Muat ulang'),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: loadData,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(child: ListTile(
              leading: const Icon(Icons.storage),
              title: Text(app['name']?.toString() ?? 'Database Domain'),
              subtitle: Text('Versi ${app['version'] ?? '-'}'),
            )),
            const SizedBox(height: 12),
            if (loading)
              const Padding(padding: EdgeInsets.all(32),
                child: Center(child: CircularProgressIndicator()))
            else if (error != null)
              Card(child: Padding(padding: const EdgeInsets.all(16),
                child: Column(children: [
                  Text('Gagal mengambil data:\n$error'),
                  const SizedBox(height: 8),
                  FilledButton(onPressed: loadData, child: const Text('Coba lagi')),
                ])))
            else ...[
              Text('Daftar domain (${domains.length})',
                style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              if (domains.isEmpty) const Text('Belum ada domain.'),
              ...domains.map((item) {
                final d = item is Map ? Map<String, dynamic>.from(item) : <String, dynamic>{};
                final active = d['status'] == 'active';
                return Card(child: ListTile(
                  leading: Icon(active ? Icons.language : Icons.public_off),
                  title: Text(d['name']?.toString() ?? 'Domain'),
                  subtitle: Text('${d['domain'] ?? '-'}\n${d['url'] ?? ''}'),
                  isThreeLine: true,
                  trailing: Chip(label: Text(d['status']?.toString() ?? 'unknown')),
                ));
              }),
            ],
            const SizedBox(height: 16),
            const Text('Data dibaca dari GitHub Raw. Edit file JSON di GitHub, lalu tekan refresh untuk mengambil perubahan.',
              style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

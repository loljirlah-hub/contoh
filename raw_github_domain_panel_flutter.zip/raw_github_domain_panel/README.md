# Raw GitHub Domain Panel

Aplikasi Flutter contoh untuk membaca `domain-panel.json` dari GitHub Raw.

## Menjalankan
1. Ekstrak ZIP dan buka folder proyek.
2. Jalankan `flutter pub get`.
3. Jalankan `flutter run`.

## URL JSON
Jika username/repository kamu berbeda, ubah `rawJsonUrl` di `lib/main.dart`:
`https://raw.githubusercontent.com/loljirlah-hub/contoh/main/domain-panel.json`

## Update data
Edit `domain-panel.json` di GitHub, tekan **Commit changes**, lalu refresh aplikasi.

## Batasan keamanan
Aplikasi ini hanya membaca JSON. GitHub Raw tidak menyediakan fungsi untuk menyimpan perubahan dari aplikasi. Untuk fitur edit/tambah/hapus melalui Admin Panel diperlukan backend/API dengan autentikasi. Jangan pernah menaruh GitHub Personal Access Token di dalam aplikasi Flutter.
